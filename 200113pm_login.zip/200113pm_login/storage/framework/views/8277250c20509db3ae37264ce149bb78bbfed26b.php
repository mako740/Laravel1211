<?php echo e($slot); ?>

<?php /**PATH C:\Users\m-yokoyama\Desktop\20200109login\login\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/subcopy.blade.php ENDPATH**/ ?>