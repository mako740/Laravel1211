<?php $__env->startSection('title', 'Laravel チュートリアル（初級）'); ?>
 
<?php $__env->startSection('content'); ?>
<h3>従業員登録画面</h3>
<p><span class="label label-danger">入力画面</span> -> 確認画面 -> 完了画面</p>
 
<form action="<?php echo e(route('insert.confirm')); ?>" method="post" class="form-horizontal">
  <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
  <div class="form-group <?php if($errors->has('username')): ?> has-error <?php endif; ?>">
  <label class="col-sm-2 control-label" for="username">名前：</label>
  <div class="col-sm-10">
  <input type="text" class="form-control" id="username" name="username" placeholder="お名前を入力してください" value="<?php echo e(old('username')); ?>">
  <?php if($errors->has('username')): ?><span class="text-danger"><?php echo e($errors->first('username')); ?></span> <?php endif; ?>
  </div>
  </div>
  <div class="form-group <?php if($errors->has('mail')): ?> has-error <?php endif; ?>">
  <label class="col-sm-2 control-label" for="mail">Email：</label>
  <div class="col-sm-10">
  <input type="text" class="form-control" id="mail" name="mail" placeholder="Emailを入力してください" value="<?php echo e(old('mail')); ?>">
  <?php if($errors->has('mail')): ?><span class="text-danger"><?php echo e($errors->first('mail')); ?></span> <?php endif; ?>
  </div>
  </div>
  <div class="form-group <?php if($errors->has('age')): ?> has-error <?php endif; ?>">
  <label class="col-sm-2 control-label" for="age">年齢：</label>
  <div class="col-sm-2">
  <input type="text" class="form-control" id="age" name="age" placeholder="年齢" value="<?php echo e(old('age')); ?>">
  </div>
  <div class="col-sm-8">歳　<?php if($errors->has('age')): ?><span class="text-danger"><?php echo e($errors->first('age')); ?></span> <?php endif; ?></div>
  </div>
  <div class="form-group">
  <div class="col-sm-offset-2 col-sm-10 text-center">
  <input type="submit" name="button1" value="送信" class="btn btn-primary btn-wide" />
  </div>
  </div>
</form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master_insert', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\m-yokoyama\Desktop\20200109login\login\resources\views/insert/index.blade.php ENDPATH**/ ?>