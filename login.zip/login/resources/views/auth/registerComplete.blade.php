@extends('layouts.app')

@section('content')
登録完了しました！

@endsection